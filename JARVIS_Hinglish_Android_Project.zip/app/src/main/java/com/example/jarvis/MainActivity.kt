package com.example.jarvis

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var response: TextView
    private lateinit var commandInput: EditText
    private var torchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF050A12.toInt())
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 32f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(0xFF42D9FF.toInt())
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "OFFLINE PHONE ASSISTANT  •  HINGLISH"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFF9CB8C8.toInt())
            setPadding(0, 10, 0, 28)
        }
        root.addView(subtitle)

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 92f
            gravity = Gravity.CENTER
            setTextColor(0xFF42D9FF.toInt())
        }
        root.addView(orb, LinearLayout.LayoutParams(-1, 150))

        response = TextView(this).apply {
            text = "Namaste! Main JARVIS hoon. Command type karein."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(8, 18, 8, 22)
        }
        root.addView(response, LinearLayout.LayoutParams(-1, -2))

        commandInput = EditText(this).apply {
            hint = "Try: torch on karo"
            setHintTextColor(0xFF78909C.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(true)
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xFF132131.toInt())
        }
        root.addView(commandInput, LinearLayout.LayoutParams(-1, -2))

        val run = Button(this).apply {
            text = "RUN COMMAND"
            setOnClickListener { handleCommand(commandInput.text.toString()) }
        }
        root.addView(run, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })

        val quick = listOf(
            "Torch on karo" to { handleCommand("torch on karo") },
            "Battery kitni hai?" to { handleCommand("battery") },
            "Volume 50%" to { handleCommand("volume 50") },
            "Settings kholo" to { handleCommand("settings kholo") }
        )
        quick.forEach { (label, action) ->
            val button = Button(this).apply {
                text = label
                setOnClickListener { action() }
            }
            root.addView(button, LinearLayout.LayoutParams(-1, -2))
        }

        val note = TextView(this).apply {
            text = "Starter build: typed commands work offline. Voice and local AI are later upgrades."
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFF78909C.toInt())
            setPadding(0, 18, 0, 0)
        }
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun say(message: String) {
        response.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT).trim()
        when {
            c.contains("torch") || c.contains("flashlight") || c.contains("flash light") || c.contains("टॉर्च") -> {
                val turnOn = c.contains("on") || c.contains("chalu") || c.contains("चालू")
                val turnOff = c.contains("off") || c.contains("band") || c.contains("बंद")
                setTorch(if (turnOn) true else if (turnOff) false else !torchOn)
            }
            c.contains("battery") || c.contains("बैटरी") -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                say("Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent hai.")
            }
            c.contains("volume") || c.contains("आवाज़") -> {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val pct = Regex("\\d+").find(c)?.value?.toIntOrNull()?.coerceIn(0, 100) ?: 50
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (max * pct / 100.0).toInt(), 0)
                say("Media volume $pct percent set kar diya.")
            }
            c.contains("brightness") || c.contains("चमक") -> {
                say("Brightness setting khol raha hoon.")
                startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            }
            c.contains("wifi") || c.contains("wi-fi") -> {
                say("Wi-Fi settings khol raha hoon. Android app se direct toggle restricted hai.")
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
            c.contains("bluetooth") -> {
                say("Bluetooth settings khol raha hoon.")
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            }
            c.contains("settings") || c.contains("setting") || c.contains("सेटिंग") -> {
                say("Settings khol raha hoon.")
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            c.contains("youtube") -> launchApp("com.google.android.youtube", "YouTube")
            c.contains("chrome") -> launchApp("com.android.chrome", "Chrome")
            c.contains("home") -> {
                say("Home screen par ja rahe hain.")
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                startActivity(i)
            }
            c.contains("time") || c.contains("समय") -> {
                val time = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                say("Abhi time $time hai.")
            }
            else -> say("Ye command abhi mujhe nahi aati. Torch, battery, volume, settings, Wi-Fi ya YouTube try karein.")
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (cameraId == null) { say("Is phone par flashlight available nahi hai."); return }
            manager.setTorchMode(cameraId, on)
            torchOn = on
            say(if (on) "Torch on kar di." else "Torch off kar di.")
        } catch (_: Exception) {
            say("Torch control nahi ho paaya. Camera permission ya phone restriction check karein.")
        }
    }

    private fun launchApp(packageName: String, label: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            say("$label khol raha hoon.")
            startActivity(intent)
        } else say("$label app nahi mili.")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
