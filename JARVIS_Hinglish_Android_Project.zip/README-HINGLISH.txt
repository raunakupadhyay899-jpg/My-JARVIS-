PROJECT JARVIS — Starter Android app

This is source code, not an installed APK.

What this starter does:
- Offline typed command matching
- Speaks responses using the phone's installed TextToSpeech engine (offline voice availability depends on installed language data)
- Flashlight on/off
- Battery percentage
- Media volume adjustment
- Opens Settings, Wi-Fi settings, Bluetooth settings and Display settings
- Opens YouTube or Chrome if installed
- Opens Home screen

Important limitations:
- Voice recognition, always-listening wake word, and local AI are NOT included yet.
- Android may restrict some actions. Wi-Fi and airplane mode cannot generally be toggled directly by ordinary apps.
- This project needs an Android build environment to produce an APK. It is not an APK itself.

Build target:
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- Compile SDK 35
- Minimum Android 8.0 (API 26)

For safety, review permissions and source before installing any APK.
